from .round_tracks_action import ActionRoundTracks
ActionRoundTracks().register()